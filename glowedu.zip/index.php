<?php include('./components/header.php') ?>
<?php include('./includes/global.php'); ?>
<title>Dashboard || Glowedu</title>
<div class="app-main__outer">
    <div class="app-main__inner">
        <div class="row">
            <div class="col-md-6 col-xl-4">
                <div class="card mb-3 widget-content bg-midnight-bloom">
                    <div class="widget-content-wrapper text-white">
                        <div class="widget-content-left">
                            <div class="widget-heading">Users</div>
                            <div class="widget-subheading">Total Number of Users</div>
                        </div>
                        <div class="widget-content-right">
                            <div class="widget-numbers text-white"><span><?php
                                                                            $query = "SELECT * FROM users";
                                                                            $result = mysqli_query($conn, $query);
                                                                            echo $rowcount = mysqli_num_rows($result);
                                                                            ?></span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="card mb-3 widget-content bg-arielle-smile">
                    <div class="widget-content-wrapper text-white">
                        <div class="widget-content-left">
                            <div class="widget-heading">Courses</div>
                            <div class="widget-subheading">Total Courses</div>
                        </div>
                        <div class="widget-content-right">
                            <div class="widget-numbers text-white"><span><?php
                                                                            $query = "SELECT * FROM courses";
                                                                            $result = mysqli_query($conn, $query);
                                                                            echo $rowcount = mysqli_num_rows($result);
                                                                            ?></span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="card mb-3 widget-content bg-grow-early">
                    <div class="widget-content-wrapper text-white">
                        <div class="widget-content-left">
                            <div class="widget-heading">Student</div>
                            <div class="widget-subheading">People Student</div>
                        </div>
                        <div class="widget-content-right">
                            <div class="widget-numbers text-white"><span><?php
                                                                            $query = "SELECT * FROM users WHERE user_type = 'student'";
                                                                            $result = mysqli_query($conn, $query);
                                                                            echo $rowcount = mysqli_num_rows($result);
                                                                            ?></span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-lg-6">
                <div class="mb-3 card">
                    <div class="card-header-tab card-header-tab-animation card-header">
                        <div class="card-header-title">
                            <i class="header-icon lnr-apartment icon-gradient bg-love-kiss">
                            </i>
                            Recent Students
                        </div>
                        <ul class="nav">
                            <li class="nav-item"><a href="javascript:void(0);" class="active nav-link">Last</a></li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="tabs-eg-77">
                                <h6 class="text-muted text-uppercase font-size-md opacity-5 font-weight-normal">Top Students</h6>
                                <div class="scroll-area-sm">
                                    <div class="scrollbar-container">
                                        <ul class="rm-list-borders rm-list-borders-scroll list-group list-group-flush">
                                            <?php
                                            $query = "SELECT * FROM users WHERE user_type = 'student' LIMIT 10";
                                            $result = mysqli_query($conn, $query);
                                            while ($rows = mysqli_fetch_assoc($result)) {
                                                $username = $rows['username'];
                                                $email = $rows['email'];
                                                $profile_pic = $rows['profile_pic'];
                                                echo "
                                                <li class='list-group-item'>
                                                <div class='widget-content p-0'>
                                                    <div class='widget-content-wrapper'>
                                                        <div class='widget-content-left mr-3'>
                                                            <img width='42' class='rounded-circle' src='./userdata/$profile_pic' alt='' />
                                                        </div>
                                                        <div class='widget-content-left'>
                                                            <div class='widget-heading'>$username</div>
                                                            <div class='widget-subheading'>$email</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                                ";
                                            }
                                            ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 col-lg-6">
                <div class="mb-3 card">
                    <div class="card-header-tab card-header">
                        <div class="card-header-title">
                            <i class="header-icon lnr-rocket icon-gradient bg-tempting-azure">
                            </i>
                            Progress Indicators
                        </div>
                        <div class="btn-actions-pane-right">
                            <div class="nav">
                                <a href="javascript:void(0);" class="border-0 btn-pill btn-wide btn-transition active btn btn-outline-alternate">Tab 1</a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade active show" id="tab-eg-55">
                            <div class="widget-chart p-3">
                                <div class="widget-chart-content text-center">
                                    <div class="widget-description mt-0 text-warning">
                                        <i class="fa fa-arrow-left"></i>
                                        <span class="pl-1">GO to the progress pages |</span>
                                        <span class="text-muted opacity-8 pl-1">| Buy new modules to get more study material!!</span>
                                    </div>
                                </div>
                            </div>
                            <div class="pt-2 card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="widget-content">
                                            <div class="widget-content-outer">
                                                <div class="widget-content-wrapper">
                                                    <div class="widget-content-left">
                                                        <div class="widget-numbers fsize-3 text-muted"><?php
                                                                                                        $query = "SELECT * FROM match_id WHERE student_id = '$user_id' AND course_category = 'python'";
                                                                                                        $result = mysqli_query($conn, $query);
                                                                                                        echo $rowcount = mysqli_num_rows($result);
                                                                                                        ?>%</div>
                                                    </div>
                                                    <div class="widget-content-right">
                                                        <div class="text-muted opacity-6">Python</div>
                                                    </div>
                                                </div>
                                                <div class="widget-progress-wrapper mt-1">
                                                    <div class="progress-bar-sm progress-bar-animated-alt progress">
                                                        <div class="progress-bar bg-danger" role="progressbar" aria-valuenow="63" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $rowcount ?>%"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="widget-content">
                                            <div class="widget-content-outer">
                                                <div class="widget-content-wrapper">
                                                    <div class="widget-content-left">
                                                        <div class="widget-numbers fsize-3 text-muted"><?php
                                                                                                        $query = "SELECT * FROM match_id WHERE student_id = '$user_id' AND course_category = 'javascript'";
                                                                                                        $result = mysqli_query($conn, $query);
                                                                                                        echo $rowcount = mysqli_num_rows($result);
                                                                                                        ?>%</div>
                                                    </div>
                                                    <div class="widget-content-right">
                                                        <div class="text-muted opacity-6">Javascript</div>
                                                    </div>
                                                </div>
                                                <div class="widget-progress-wrapper mt-1">
                                                    <div class="progress-bar-sm progress-bar-animated-alt progress">
                                                        <div class="progress-bar bg-success" role="progressbar" aria-valuenow="32" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $rowcount; ?>%"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="widget-content">
                                            <div class="widget-content-outer">
                                                <div class="widget-content-wrapper">
                                                    <div class="widget-content-left">
                                                        <div class="widget-numbers fsize-3 text-muted"><?php
                                                                                                        $query = "SELECT * FROM match_id WHERE student_id = '$user_id' AND course_category = 'cc_plus'";
                                                                                                        $result = mysqli_query($conn, $query);
                                                                                                        echo $rowcount = mysqli_num_rows($result);
                                                                                                        ?>%</div>
                                                    </div>
                                                    <div class="widget-content-right">
                                                        <div class="text-muted opacity-6">C & C ++</div>
                                                    </div>
                                                </div>
                                                <div class="widget-progress-wrapper mt-1">
                                                    <div class="progress-bar-sm progress-bar-animated-alt progress">
                                                        <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="71" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $rowcount; ?>%"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="main-card mb-3 card">
                    <div class="card-header">
                        <div class="btn-actions-pane-right">
                            <div role="group" class="btn-group-sm btn-group">
                                Q&A
                            </div>
                        </div>
                    </div>
                    <div class="d-block text-center card-footer">
                        <button class="mr-2 btn-icon btn-icon-only btn btn-outline-dark"><i class="pe-7s-album btn-icon-wrapper"> </i> View All</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('./components/footer.php'); ?>
<?php include('./components/scripts.php'); ?>