<script type="text/javascript" src="./assets/scripts/main.js"></script>
</body>

</html>